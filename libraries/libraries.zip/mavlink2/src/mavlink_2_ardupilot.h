#pragma once


#include "ardupilotmega/mavlink.h"
